#include "car_traj_ctrl/car_kin_trajctrl.h" 

#include <unistd.h>


void car_kin_trajctrl::Prepare(void)
{
    /* Retrieve parameters from ROS parameter server */
    std::string FullParamName;

//     // sampling time
//     FullParamName = ros::this_node::getName()+"/Ts";
//     if (false == ctrl_nh.getParam(FullParamName, Ts))
//         ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    // run_period
    FullParamName = ros::this_node::getName()+"/run_period";
    if (false == ctrl_nh.getParam(FullParamName, RunPeriod))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    // Controller parameters
    FullParamName = ros::this_node::getName()+"/P_dist";
    if (false == ctrl_nh.getParam(FullParamName, P_dist))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    FullParamName = ros::this_node::getName()+"/l";
    if (false == ctrl_nh.getParam(FullParamName, l))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    FullParamName = ros::this_node::getName()+"/Kx";
    if (false == ctrl_nh.getParam(FullParamName, Kx))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    FullParamName = ros::this_node::getName()+"/Ky";
    if (false == ctrl_nh.getParam(FullParamName, Ky))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

//     FullParamName = ros::this_node::getName()+"/Tx";
//     if (false == ctrl_nh.getParam(FullParamName, Tx))
//         ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

//     FullParamName = ros::this_node::getName()+"/Ty";
//     if (false == ctrl_nh.getParam(FullParamName, Ty))
//         ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    // trajectory parameters 
    FullParamName = ros::this_node::getName()+"/a_traj";
    if (false == ctrl_nh.getParam(FullParamName, a_traj))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());

    FullParamName = ros::this_node::getName()+"/T";
    if (false == ctrl_nh.getParam(FullParamName, T))
        ROS_ERROR("Node %s: unable to retrieve parameter %s.", ros::this_node::getName().c_str(), FullParamName.c_str());


    /* ROS topics */
    vehicleState_subscriber = ctrl_nh.subscribe("/car_state", 1, &car_kin_trajctrl::vehicleState_MessageCallback, this);
    vehicleCommand_publisher = ctrl_nh.advertise<std_msgs::Float64MultiArray>("/car_input", 1);
    controllerState_publisher = ctrl_nh.advertise<std_msgs::Float64MultiArray>("/controller_state", 1);

    /* Create controller class */
    controller = new car_kin_fblin(P_dist);

    // Initialize controller parameters
    controller->set_carParam(l);

    ROS_INFO("Node %s ready to run.", ros::this_node::getName().c_str());
}

void car_kin_trajctrl::RunPeriodically(float Period)
{
    ros::Rate LoopRate(1.0/Period);

    ROS_INFO("Node %s running periodically (T=%.2fs, f=%.2fHz).", ros::this_node::getName().c_str(), Period, 1.0/Period);
    int initialized = 0;

    while (ros::ok())
    {
        PeriodicTask(initialized);

        ros::spinOnce();

        LoopRate.sleep();
    }
}

void car_kin_trajctrl::Shutdown(void)
{
    // Delete controller object
    delete controller;

    ROS_INFO("Node %s shutting down.", ros::this_node::getName().c_str());
}

void car_kin_trajctrl::vehicleState_MessageCallback(const std_msgs::Float64MultiArray::ConstPtr& msg)
{
    // Input command: t, msg->data[0]; x, msg->data[1]; y, msg->data[2]; theta, msg->data[3];
    // linear velocity, msg->data[4]; angular velocity, msg->data[5]
    /*  Set vehicle state */
    controller->set_carState(msg->data.at(1), msg->data.at(2), msg->data.at(3));
}

void car_kin_trajctrl::PeriodicTask(int initialized)
{
    /* 8-shaped trajectory generation */
    // Trajectory computation 
    const double pi = 3.14159265358979323846;
    double ePx;
    double ePy;
    double ePxprev;
    double ePyprev; 
    double vPx_prev;
    double vPy_prev;
    
    if(initialized == 0){
        // ROS_INFO("ciao, %d", initialized);
        ePx = 0.0;
        ePy = 0.0;
        ePxprev = 0.0;
        ePyprev = 0.0;
        vPx_prev = 0.0;
        vPy_prev = 0.0;
        initialized = 1;
    }

    xref    = a_traj*std::sin(2*pi/T*ros::Time::now().toSec());
    dxref   = 2*pi/T*a_traj*std::cos(2*pi/T*ros::Time::now().toSec());
    yref    = a_traj*std::sin(2*pi/T*ros::Time::now().toSec())*std::cos(2*pi/T*ros::Time::now().toSec());
    dyref   = 2*pi/T*a_traj*(std::pow(std::cos(2*pi/T*ros::Time::now().toSec()),2.0)-std::pow(std::sin(2*pi/T*ros::Time::now().toSec()),2.0));

    // // trajectory computation square 
    // if(ros::Time::now().toSec() <= 2){
    //     xref  = 0;
    //     dxref = 0;
    //     yref  = ros::Time::now().toSec()-0.011;
    //     dyref = 1;
    // }else if(ros::Time::now().toSec() > 2 && ros::Time::now().toSec() <= 4){
    //     xref  = -2+ros::Time::now().toSec();
    //     dxref = 1;
    //     yref  = 2-0.011;
    //     dyref = 0;
    // }else if(ros::Time::now().toSec() > 4 && ros::Time::now().toSec() <= 6){
    //     xref  = 2;
    //     dxref = 0;
    //     yref  = 6-0.011-ros::Time::now().toSec();
    //     dyref = -1;
    // }else if(ros::Time::now().toSec() > 6 && ros::Time::now().toSec() <= 8){
    //     xref  = 8-ros::Time::now().toSec();
    //     dxref = -1;
    //     yref  = 0;
    //     dyref = 0;
    // }else{
    //     xref  = ros::Time::now().toSec()-8;
    //     dxref = 1;
    //     yref  = ros::Time::now().toSec()-8;
    //     dyref = 1;
    // }

//     // trajectory computation circle
    // int R = 5;
    // xref  = R*std::cos(2*pi/T*ros::Time::now().toSec())-R;
    // dxref = R*2*pi/T*(-std::sin(2*pi/T*ros::Time::now().toSec()));
    // yref  = R*std::sin(2*pi/T*ros::Time::now().toSec());
    // dyref = R*2*pi/T*(std::cos(2*pi/T*ros::Time::now().toSec()));


    /*  Compute the control action */
    // Transform trajectory to point P
    controller->reference_transformation(xref, yref, xPref, yPref);
    controller->output_transformation(xP, yP);                         //define new point P position 

    // Trajectory tracking law P controller
    // vPx = dxref+Kx*(xPref-xP);
    // vPy = dyref+Ky*(yPref-yP);

// Trajectory tracking law PI controller
    // vPx = dxref + vPx_prev + Kx*((xPref-xP) - (ePx)) + Kx*Ts/Tx*(ePx);
    // vPy = dyref + vPy_prev + Ky*((yPref-yP) - (ePy)) + Ky*Ts/Ty*(ePy);  

    ePx = xPref-xP;
    ePy = yPref-yP;

    // Backward euler
    // vPx = dxref + vPx_prev + Kx*(ePx - ePxprev) + Kx*Ts/Tx*ePx;
    // vPy = dyref + vPy_prev + Ky*(ePy - ePyprev) + Ky*Ts/Ty*ePy;

    // forward euler
    vPx = dxref + vPx_prev + Kx*(ePx - ePxprev) + Kx*(Ts/Tx)*(ePxprev);
    vPy = dyref + vPy_prev + Ky*(ePy - ePyprev) + Ky*(Ts/Ty)*(ePyprev);  

    ePxprev = ePx;
    ePyprev = ePy;
    vPx_prev = vPx;
    vPy_prev = vPy;
    // ROS_INFO("%f, %f, %f, %f", vPx_prev, vPy_prev, ePx, ePy);

    // Linearization law
    controller->control_transformation(vPx, vPy, v, phi);;

    /*  Publish vehicle commands */
    std_msgs::Float64MultiArray vehicleCommandMsg;
    vehicleCommandMsg.data.push_back(ros::Time::now().toSec());
    vehicleCommandMsg.data.push_back(v);
    vehicleCommandMsg.data.push_back(phi);
    vehicleCommand_publisher.publish(vehicleCommandMsg);

    /*  Publish controller state */
    std_msgs::Float64MultiArray controllerStateMsg;
    controllerStateMsg.data.push_back(ros::Time::now().toSec());
    controllerStateMsg.data.push_back(xref);
    controllerStateMsg.data.push_back(yref);
    controllerStateMsg.data.push_back(xPref);
    controllerStateMsg.data.push_back(yPref);
    controllerStateMsg.data.push_back(xP);
    controllerStateMsg.data.push_back(yP);
    controllerStateMsg.data.push_back(vPx);
    controllerStateMsg.data.push_back(vPy);
    controllerStateMsg.data.push_back(v);
    controllerStateMsg.data.push_back(phi);
    controllerState_publisher.publish(controllerStateMsg);
}
