#include "car_traj_ctrl/car_kin_trajctrl.h"


int main(int argc, char **argv)
{
  ros::init(argc, argv, NAME_OF_THIS_NODE);
  
  car_kin_trajctrl car_kin_trajctrl_node;
   
  car_kin_trajctrl_node.Prepare();
  
  car_kin_trajctrl_node.RunPeriodically(car_kin_trajctrl_node.RunPeriod);
  
  car_kin_trajctrl_node.Shutdown();
  
  return (0);
}

