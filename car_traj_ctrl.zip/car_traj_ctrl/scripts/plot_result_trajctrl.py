import sys
import rosbag
import matplotlib.pyplot as plt
import numpy as np

# Read data from bag
bag = rosbag.Bag(sys.argv[1])

# State published by the simulator
vehicleState_time = []
vehicleState_x = []
vehicleState_y = []
vehicleState_theta = []
vehicleState_velocity = []
vehicleState_steer = []
vehicleState_ForceFront = []
vehicleState_ForceRear = []

# State published by the controller
controllerState_time = []
controllerState_xref = []
controllerState_yref = []
controllerState_xPref = []
controllerState_yPref = []
controllerState_xP = []
controllerState_yP = []
controllerState_vPx = []
controllerState_vPy = []
controllerState_velocity = []
controllerState_steer = []
controllerState_xPerr = []
controllerState_yPerr = []

for topic, msg, t in bag.read_messages():
    # print(topic)
    if topic == "/car_state":
        vehicleState_time.append(msg.data[0])
        vehicleState_x.append(msg.data[1])
        vehicleState_y.append(msg.data[2])
        vehicleState_theta.append(msg.data[3])
        vehicleState_velocity.append(msg.data[12])
        vehicleState_steer.append(msg.data[13])
        vehicleState_ForceFront.append(msg.data[10])
        vehicleState_ForceRear.append(msg.data[11])

    if topic == "/controller_state":
        controllerState_time.append(msg.data[0])
        controllerState_xref.append(msg.data[1])
        controllerState_yref.append(msg.data[2])
        controllerState_xPref.append(msg.data[3])
        controllerState_yPref.append(msg.data[4])
        controllerState_xP.append(msg.data[5])
        controllerState_yP.append(msg.data[6])
        controllerState_vPx.append(msg.data[7])
        controllerState_vPy.append(msg.data[8])
        controllerState_velocity.append(msg.data[9])
        controllerState_steer.append(msg.data[10])
        controllerState_xPerr.append(msg.data[3]-msg.data[5])
        controllerState_yPerr.append(msg.data[4]-msg.data[6])

bag.close()

# Plot data
# robot trajectory
plt.figure(1)
plt.plot(vehicleState_x,vehicleState_y, label="real trajectory")                                                         # followed traj
plt.plot(vehicleState_x[0],vehicleState_y[0],'ro')                                              # initial position
plt.plot(vehicleState_x[len(vehicleState_x)-1],vehicleState_y[len(vehicleState_x)-1],'rx')      # final position
plt.plot(controllerState_xref,controllerState_yref,'g', label="reference trajectory")                                         # reference traj
plt.legend()
plt.xlabel("x [m]")
plt.ylabel("y [m]")
plt.title("Robot trajectory")

#control actions
plt.figure(2)
plt.subplot(211)
plt.title("Control actions")
plt.plot(vehicleState_time,vehicleState_velocity)
plt.xlabel("Time [s]")
plt.ylabel("Longitudinal velocity [m/s]")
plt.subplot(212)
plt.plot(vehicleState_time,vehicleState_steer)
plt.xlabel("Time [s]")
plt.ylabel("Steer position [rad]")

# # x_traj, y_traj, theta
# plt.figure(3)
# plt.subplot(311)
# plt.title("x_traj, y_traj, theta")
# plt.plot(vehicleState_time,vehicleState_x, label="x act")
# plt.plot(controllerState_time,controllerState_xref, 'r--', label="x ref")
# plt.xlabel("Time [s]")
# plt.ylabel("x [m]")
# plt.legend(loc='best')
# plt.subplot(312)
# plt.plot(vehicleState_time,vehicleState_y, label="y act")
# plt.plot(controllerState_time,controllerState_yref, 'r--', label="y ref")
# plt.xlabel("Time [s]")
# plt.ylabel("y [m]")
# plt.legend(loc='best')
# plt.subplot(313)
# plt.plot(vehicleState_time,vehicleState_theta)
# plt.xlabel("Time [s]")
# plt.ylabel("theta [rad]")

# x and y position errors of P
plt.figure(4)
plt.subplot(211)
plt.title("x and y position errors of P")
plt.plot(controllerState_time,controllerState_xPerr)
plt.xlabel("Time [s]")
plt.ylabel("x position error [m]")
plt.subplot(212)
plt.plot(controllerState_time,controllerState_yPerr)
plt.xlabel("Time [s]")
plt.ylabel("y position error [m]")
print("max x error: ",max(controllerState_xPerr), "max y error: ",max(controllerState_yPerr))
print("average x error: ", np.mean(np.abs(controllerState_xPerr)), "average y error: ", np.mean(np.abs(controllerState_yPerr)))
# vPx vPy
# plt.figure(5)
# plt.subplot(211) 
# plt.title("vPx, vPy")
# plt.plot(controllerState_time,controllerState_vPx)
# plt.xlabel("time [s]")
# plt.ylabel("vPx [m/s]")
# plt.subplot(212)
# plt.plot(controllerState_time,controllerState_vPy)
# plt.xlabel("time [s]")
# plt.ylabel("vPy [m/s]")
# plt.show()
plt.figure(6)
plt.subplot(211) 
plt.title("Force front, force Rear")
plt.plot(vehicleState_time, vehicleState_ForceFront)
plt.xlabel("time [s]")
plt.ylabel("Force front [N]]")
plt.subplot(212)
plt.plot(vehicleState_time,vehicleState_ForceRear)
plt.xlabel("time [s]")
plt.ylabel("Force rear [N]")
plt.show()
