#include "car_sim/sim_tester.h"

void sim_tester::Prepare(void)
{
    /* ROS topics */
    vehicleCommand_publisher = nh2.advertise<std_msgs::Float64MultiArray>("/car_input", 1);

    /* Initialize node state */
    RunPeriod = RUN_PERIOD_DEFAULT;

    steer = velocity = 0.0;

    ROS_INFO("Node %s ready to run.", ros::this_node::getName().c_str());
}

void sim_tester::RunPeriodically(float Period)
{
    ros::Rate LoopRate(1.0/Period);

    ROS_INFO("Node %s running periodically (T=%.2fs, f=%.2fHz).", ros::this_node::getName().c_str(), Period, 1.0/Period);

    while (ros::ok())
    {
        PeriodicTask();

        ros::spinOnce();

        LoopRate.sleep();
    }
}

void sim_tester::Shutdown(void)
{
    ROS_INFO("Node %s shutting down.", ros::this_node::getName().c_str());
}

void sim_tester::PeriodicTask(void)
{
    /* Vehicle commands */
    if (ros::Time::now().toSec()<=5.0)
    {
        velocity = 1.0;
        steer = 0.0;
    }
    else
    {
        velocity = 1.0;
        steer = 0.1;
    }

    /* Publishing vehicle commands (t, msg->data[0]; velocity, msg->data[1]; steer, msg->data[2]) */
    std_msgs::Float64MultiArray msg;
    msg.data.push_back(ros::Time::now().toSec());
    msg.data.push_back(velocity);
    msg.data.push_back(steer);
    vehicleCommand_publisher.publish(msg);
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, NAME_OF_THIS_NODE);
  
  sim_tester sim_tester_node;
   
  sim_tester_node.Prepare();
  
  sim_tester_node.RunPeriodically(sim_tester_node.RunPeriod);
  
  sim_tester_node.Shutdown();
  
  return (0);
}

